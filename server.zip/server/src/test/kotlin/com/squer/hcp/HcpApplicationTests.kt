package com.squer.hcp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HcpApplicationTests {

	@Test
	fun contextLoads() {
	}

}
