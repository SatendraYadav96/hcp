package com.squer.hcp.service.ui.impl

import com.squer.hcp.controller.dto.FormMetaDTO
import com.squer.hcp.domain.ui.FormLabelMeta
import com.squer.hcp.repository.ui.FormLabelRepository
import com.squer.hcp.repository.ui.FormMetaRepository
import com.squer.hcp.service.ui.FormService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class FormServiceImpl @Autowired constructor(
private val formMetaRepository: FormMetaRepository,
private val formLabelRepository: FormLabelRepository
): FormService {

    override fun getFormMeta(formCode: String): FormMetaDTO? {
        val formMeta = formMetaRepository.getFormMetaByFormCode(formCode)
        if (formMeta == null) return null
        var meta = FormMetaDTO()
        val labels = mutableMapOf<String, FormLabelMeta>()
        formMeta.forEach { it ->
            val label = formLabelRepository.getFormLabelMetaByCode(it.code!!)
            labels[it.code!!] = label!!
        }
        meta.fields = labels
        return meta;
    }
}
