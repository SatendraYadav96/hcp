package com.squer.hcp.service.ui

import com.squer.hcp.controller.dto.FormMetaDTO

interface FormService {

    fun getFormMeta(formCode: String): FormMetaDTO?
}
