package com.squer.hcp.security.repository

import com.squer.hcp.mapper.SecurityRoleMapper
import com.squer.hcp.persistence.BaseRepository
import com.squer.hcp.security.domain.SecurityRole
import com.squer.hcp.security.domain.User
import com.squer.hcp.security.util.SecurityUtility
import org.apache.ibatis.annotations.Select
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository

@Repository
class SecurityRoleRepository(
    securityUtility: SecurityUtility
): BaseRepository<User>(
    securityUtility= securityUtility,
) {
    @Autowired
    lateinit var userRoleMapper: SecurityRoleMapper


    fun findByUser(userId: String): List<SecurityRole>? {
        return userRoleMapper.findByUserId(userId)
    }
}
