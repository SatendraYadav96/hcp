package com.squer.hcp.api.v1

import com.squer.hcp.controller.DoctorController
import com.squer.hcp.controller.DocumentTypeController
import com.squer.hcp.controller.UserController
import com.squer.hcp.security.jwt.JwtTokenProvider
import com.squer.hcp.service.DoctorService
import com.squer.hcp.service.DocumentTypeService
import com.squer.hcp.service.EmployeeService
import com.squer.hcp.service.UserService
import com.squer.hcp.validator.MapValidationErrorService
import com.squer.hcp.validator.UserValidator
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder

import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/v1/documenttype")
@Tag(name = "V1 Document type APIs")
@SecurityRequirement(name = "bearer-key")
@CrossOrigin
class DocumentTypeApiV1(
    documentTypeService: DocumentTypeService
) :
    DocumentTypeController(
        documentTypeService = documentTypeService
    )
