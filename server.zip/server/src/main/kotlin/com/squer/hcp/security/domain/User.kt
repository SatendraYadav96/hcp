package com.squer.hcp.security.domain

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.squer.hcp.security.domain.enum.UserStatusEnum
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.userdetails.UserDetails
import javax.validation.constraints.NotBlank
import kotlin.collections.HashSet

class   User : java.io.Serializable, UserDetails, AuditableEntity() {
    private var username: @NotBlank(message = "Please enter username") String? = null

    private var password: String? = null

    var fullName: @NotBlank(message = "Please enter full name") String? = null

    var status: @NotBlank(message = "Please add status") UserStatusEnum? = null

    var roles: List<SecurityRole>? = mutableListOf<SecurityRole>()

    @JsonIgnore
    override fun getAuthorities(): MutableCollection<out GrantedAuthority> {
        val authorities: MutableSet<GrantedAuthority> = HashSet()
        authorities.add(SimpleGrantedAuthority("ADMIN"))
        return authorities
    }

    override fun getUsername(): String? = username

    @JsonIgnore
    @JsonProperty(value = "password")
    override fun getPassword(): String? = password

    fun setPassword(value: String?) {
        password = value
    }

    @JsonIgnore
    override fun isAccountNonExpired(): Boolean = true

    @JsonIgnore
    override fun isAccountNonLocked(): Boolean = true

    @JsonIgnore
    override fun isCredentialsNonExpired(): Boolean = true

    @JsonIgnore
    override fun isEnabled(): Boolean = true

}
