package com.squer.hcp.service

import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.domain.HCPDocumentStore
import com.squer.hcp.domain.JobTitle
import org.springframework.data.domain.Page

interface JobTitleService {
    fun findAll(): List<JobTitle>?
}
