package com.squer.hcp.repository

import com.squer.hcp.domain.Employee
import com.squer.hcp.domain.JobTitle
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
class EmployeeRepository {//: JpaRepository<Employee, String> {

    fun findEmployeeByUserId(@Param("userId")userId: String): Employee? {
        return null
    }

    /*
    @Query("select * from employee e inner join ( WITH RECURSIVE T AS ( SELECT ID, NAME, MANAGER_ID FROM  " +
            "EMPLOYEE UNION  ALL SELECT T.ID, T.NAME, E.MANAGER_ID FROM   EMPLOYEE AS E JOIN T ON T.MANAGER_ID = E.ID) " +
            " SELECT MANAGER_ID FROM   T where t.id = :employeeId ) m on e.id = m.manager_id", nativeQuery = true)
     */
    fun findAllManagers(@Param("employeeId")employeeId: String): List<Employee>? {
        return  null
    }

    fun findAllByJobTitle(jobTitle: JobTitle): List<Employee>? {
        return null
    }

}
