package com.squer.hcp.domain

import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SquerEntity

@EntityMeta(prefix = "acdtl", tableName = "approval_chain_details")
class ApprovalChainDetails: java.io.Serializable, SquerEntity() {

    var definition: ApprovalChainDefinition? = null

    var jobRole: JobTitle? = null

    var required: Boolean? = false

    var waitInDays: Int = 0

    var levelNo: Int = 0
}
