package com.squer.hcp.service.impl

import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.repository.DocumentStoreRepository
import com.squer.hcp.service.DocumentStoreService
import lombok.extern.slf4j.Slf4j
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service
import java.io.File
import java.util.UUID

@Service
@Slf4j
class DocumentStoreServiceImpl @Autowired constructor(
    private val documentStoreRepository: DocumentStoreRepository
) : DocumentStoreService {

    @Value("\${app.documents.path}")
    lateinit var filePath: String

    override fun storeDocument(documentStore: DocumentStore): DocumentStore? {
        val randomFileName = "${UUID.randomUUID().toString()}_${documentStore.file_name}"
        documentStore.documentPath = "$filePath/${randomFileName}"
        val document = documentStoreRepository.save(documentStore)
        if (document == null)
            throw Exception("Could not save document")
        val file = File(documentStore.documentPath).writeBytes(documentStore.content!!)
        return document
    }
}
