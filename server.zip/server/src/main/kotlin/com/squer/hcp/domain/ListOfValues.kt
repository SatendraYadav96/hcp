package com.squer.hcp.domain

import com.squer.hcp.domain.enums.LOVStatusEnum
import com.squer.hcp.domain.enums.LOVTypeEnum
import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SquerEntity
import lombok.EqualsAndHashCode
import javax.persistence.*

@EntityMeta(prefix = "loval", tableName = "list_of_values")
class ListOfValues: java.io.Serializable, SquerEntity() {

    var name: String? = null

    var ciName: String?  = null

    var displayOrder: Int = 0

    val visibile: Boolean = true

    var status: LOVStatusEnum? = null

    var lovType: LOVTypeEnum? = null

}
