package com.squer.hcp.security.service.impl

import com.squer.hcp.mapper.UserMapper
import com.squer.hcp.security.domain.User
import com.squer.hcp.security.repository.UserRepository
import com.squer.hcp.security.service.CustomUserDetailsService
import lombok.extern.slf4j.Slf4j
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.stereotype.Service
import java.util.*

@Service
@Slf4j
class CustomUserDetailsServiceImpl @Autowired constructor(
    private val userRepository: UserRepository
) : CustomUserDetailsService {

    override fun loadUserByUsername(username: String): UserDetails {
        return userRepository.findByUsername(username) ?: throw UsernameNotFoundException("User not found")
    }

    override fun loadUserById(id: String): User {
        val user = userRepository.findById(id)
        if (user == null) throw UsernameNotFoundException("User not found")
        return user
    }
}
