package com.squer.hcp.controller.dto

import com.squer.hcp.domain.Doctor

class HCPDetails {
    lateinit var doctor: Doctor
}
