package com.squer.hcp.api.v1

import com.squer.hcp.controller.DoctorController
import com.squer.hcp.service.DoctorService
import com.squer.hcp.service.EmployeeService
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag

import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/v1/doctor")
@Tag(name = "V1 Doctor APIs")
@SecurityRequirement(name = "bearer-key")
@CrossOrigin
class DoctorApiV1(
    doctorService: DoctorService,
    employeeService: EmployeeService
) :
    DoctorController(
        doctorService = doctorService,
        employeeService = employeeService
    )
