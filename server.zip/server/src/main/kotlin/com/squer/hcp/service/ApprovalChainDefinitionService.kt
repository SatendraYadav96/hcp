package com.squer.hcp.service

import com.squer.hcp.domain.ApprovalChainDefinition
import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.domain.HCPDocumentStore
import org.springframework.data.domain.Page

interface ApprovalChainDefinitionService {

    fun create(chainDefinition: ApprovalChainDefinition): ApprovalChainDefinition?
}
