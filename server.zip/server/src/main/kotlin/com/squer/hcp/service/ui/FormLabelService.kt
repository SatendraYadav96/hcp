package com.squer.hcp.service.ui

import com.squer.hcp.controller.dto.FormMetaDTO
import com.squer.hcp.domain.ui.FormLabelMeta

interface FormLabelService {

    fun fetchLabel(code: String): FormLabelMeta?

}
