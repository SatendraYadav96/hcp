package com.squer.hcp.repository.ui

import com.squer.hcp.domain.ui.FormMeta
import org.springframework.stereotype.Repository

@Repository
class FormMetaRepository { //: JpaRepository<FormMeta, Long> {

    fun getFormMetaByFormCode(code: String): List<FormMeta>? {
        return null
    }
}
