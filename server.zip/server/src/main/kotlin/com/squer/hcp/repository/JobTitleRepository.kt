package com.squer.hcp.repository

import com.squer.hcp.domain.JobTitle
import org.springframework.stereotype.Repository

@Repository
class JobTitleRepository{ //: JpaRepository<JobTitle, Long> {

    fun findAll(): List<JobTitle> {
        return mutableListOf()
    }
}
