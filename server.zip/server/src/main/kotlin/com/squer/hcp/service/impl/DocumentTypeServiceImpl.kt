package com.squer.hcp.service.impl

import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentType
import com.squer.hcp.domain.enums.DocumentTypeOwner
import com.squer.hcp.domain.enums.DocumentTypeStatus
import com.squer.hcp.repository.DocumentTypeRepository
import com.squer.hcp.service.DocumentTypeService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service


@Service
@Slf4j
class DocumentTypeServiceImpl @Autowired constructor(
    private val documentTypeRepository: DocumentTypeRepository

) : DocumentTypeService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun findTypesForOwnerType(ownerType: DocumentTypeOwner, status: DocumentTypeStatus?): List<DocumentType>? {
        if (status == null)
        return documentTypeRepository.findAllByOwnerType(ownerType)
        else
            return documentTypeRepository.findAllByOwnerTypeAndStatus(ownerType, status!!)
    }

    override fun createType(documentType: DocumentType): DocumentType? {
        return documentTypeRepository.save(documentType)
    }

    override fun changeStatus(id: String, newStatus: DocumentTypeStatus): DocumentType? {
        var type = documentTypeRepository.findById(id)
        if (type == null) throw Exception("Invalid document type")
        type.status = newStatus
        return documentTypeRepository.save(type)
    }
}
