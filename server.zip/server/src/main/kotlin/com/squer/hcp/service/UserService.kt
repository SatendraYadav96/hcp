package com.squer.hcp.service


import com.squer.hcp.security.domain.User


interface UserService {
    fun saveUser(newUser: User): User
    fun updateUser(user: User): User?
    fun findByUsername(username: String): User?
    fun restore(id: String): User?

}
