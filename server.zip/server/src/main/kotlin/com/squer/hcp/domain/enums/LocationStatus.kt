package com.squer.hcp.domain.enums

enum class LocationStatus {
    ACTIVE, INACTIVE
}
