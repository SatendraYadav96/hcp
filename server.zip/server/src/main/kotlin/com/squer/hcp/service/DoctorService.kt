package com.squer.hcp.service

import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.domain.HCPDocumentStore
import org.springframework.data.domain.Page

interface DoctorService {
    fun searchDoctors(filter: Doctor, page: Int): Page<Doctor>

    fun findDoctor(id: String): Doctor?

    fun registerDoctor(employeeId:String, doctor: Doctor, documents: MutableList<HCPDocumentStore>): Doctor?
}
