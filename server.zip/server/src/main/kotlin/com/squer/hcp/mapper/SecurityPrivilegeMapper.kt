package com.squer.hcp.mapper

import com.squer.hcp.persistence.BaseMapper
import com.squer.hcp.security.domain.SecurityPrivilege
import com.squer.hcp.security.domain.SecurityRole
import com.squer.hcp.security.domain.User
import org.apache.ibatis.annotations.*

@Mapper
interface SecurityPrivilegeMapper: BaseMapper<SecurityPrivilege> {

    @Select("SELECT SECURITY_PRIVILEGE.id id, name, ci_name from SECURITY_PRIVILEGE " +
            " inner join SECURITY_ROLE_PRIVILEGE on privilege_id = SECURITY_PRIVILEGE.id where role_id = #{roleId}")
    @ResultMap("securityRoleResultMap")
    fun findByUserId(userId: String): List<SecurityRole>?
}
