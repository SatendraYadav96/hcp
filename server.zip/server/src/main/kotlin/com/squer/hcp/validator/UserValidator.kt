package com.squer.hcp.validator

import org.springframework.validation.Validator

interface UserValidator : Validator