package com.squer.hcp.controller

import com.squer.hcp.controller.dto.HCPDetails
import com.squer.hcp.controller.dto.InvalidArgumentResponse
import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.domain.DocumentType
import com.squer.hcp.domain.HCPDocumentStore
import com.squer.hcp.security.domain.User
import com.squer.hcp.service.DoctorService
import com.squer.hcp.service.EmployeeService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile


@Slf4j
open class DoctorController @Autowired constructor(
    private val doctorService: DoctorService,
    private val employeeService: EmployeeService
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @PostMapping("/search")
    open fun searchDoctors(@RequestBody filter: Doctor, @RequestParam page: Int): Page<Doctor> {
        return doctorService.searchDoctors(filter, page)
    }

    @GetMapping("/{id}")
    open fun findDoctor(@PathVariable id: String): ResponseEntity<*> {
        val doctor = doctorService.findDoctor(id)
        if (doctor == null) {
            return ResponseEntity<Any?>(InvalidArgumentResponse(argument = id.toString(), message = "No doctor for the id"), HttpStatus.BAD_REQUEST)
        }
        val hcpDetails = HCPDetails()
        hcpDetails.doctor = doctor
        return ResponseEntity<Any?>(hcpDetails, HttpStatus.OK)
    }

    @PostMapping(value=["/register"])
    open fun registerDoctor(@RequestPart("data") doctor: Doctor,
                            @RequestPart("files") files: Array<MultipartFile>): ResponseEntity<*> {
        val authentication = SecurityContextHolder.getContext().authentication
        val employee = employeeService.findByUserId((authentication.principal as User).id!!)
        val documents = mutableListOf<HCPDocumentStore>()
        for (file in files) {
            val document = HCPDocumentStore()
            document.file_name = file.originalFilename
            document.content =  file.bytes
            documents.add(document)
        }
        return ResponseEntity<Any?>(doctorService.registerDoctor(employee?.id!!, doctor, documents), HttpStatus.OK)
    }
}
