package com.squer.hcp.domain.enums

enum class LOVTypeEnum {
    FMV_TIER, HCP_SPECIALITY
}
