package com.squer.hcp.repository

import com.squer.hcp.domain.DocumentType
import com.squer.hcp.domain.enums.DocumentTypeOwner
import com.squer.hcp.domain.enums.DocumentTypeStatus
import org.springframework.stereotype.Repository

@Repository
class DocumentTypeRepository{ //: JpaRepository<DocumentType, Long> {

    fun findAllByOwnerType(ownerType: DocumentTypeOwner): List<DocumentType>? {
        return null
    }

    fun findAllByOwnerTypeAndStatus(ownerType: DocumentTypeOwner, status: DocumentTypeStatus): List<DocumentType>? {
        return null
    }

    fun findById(id: String): DocumentType? {
        return null
    }

    fun save(documentType: DocumentType): DocumentType {
        return documentType
    }
}
