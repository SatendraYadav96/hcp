package com.squer.hcp.security.repository

import com.squer.hcp.mapper.SecurityRoleMapper
import com.squer.hcp.mapper.UserMapper
import com.squer.hcp.persistence.BaseRepository
import com.squer.hcp.security.domain.User
import com.squer.hcp.security.util.SecurityUtility
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository

@Repository
class UserRepository(
    securityUtility: SecurityUtility
): BaseRepository<User>(
    securityUtility= securityUtility,
) {
    @Autowired
    lateinit var userMapper: UserMapper

    fun findById(id: String) : User? {
        return userMapper.findUserById(id)
    }

    fun findByUsername(username: String): User? {
        return userMapper.findByUsername(username)
    }
    fun update(user: User): User {
        userMapper.update(user)
        return  user
    }
}
