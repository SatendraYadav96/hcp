package com.squer.hcp.repository

import com.squer.hcp.domain.ApprovalChainInstanceDetails
import org.springframework.stereotype.Repository

@Repository
class ApprovalChainInstanceRepository { //: JpaRepository<ApprovalChainInstanceDetails, Long> {

    fun saveAll(approvalChainInstances: List<ApprovalChainInstanceDetails>): List<ApprovalChainInstanceDetails> {
        return mutableListOf()
    }
}
