package com.squer.hcp.service


import com.squer.hcp.domain.Employee

interface EmployeeService {
    fun findByUserId(userId: String): Employee?
}
