package com.squer.hcp.domain

import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SquerEntity

@EntityMeta(prefix = "jobrl", tableName = "job_title")
class JobTitle: SquerEntity(){
    var name: String? = null

    var ciName: String? =  null

    var commonFunction: Boolean = false
}
