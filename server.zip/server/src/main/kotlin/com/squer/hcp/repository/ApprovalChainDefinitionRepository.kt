package com.squer.hcp.repository

import com.squer.hcp.domain.ApprovalChainDefinition
import com.squer.hcp.domain.enums.ApprovalChainType
import org.springframework.context.annotation.Bean
import org.springframework.stereotype.Repository

/*interface ApprovalChainDefinitionRepository: JpaRepository<ApprovalChainDefinition, Long>, JpaSpecificationExecutor<ApprovalChainDefinition>,
    PagingAndSortingRepository<ApprovalChainDefinition, Long> { */
@Repository
class ApprovalChainDefinitionRepository {

        fun findByType(type: ApprovalChainType): ApprovalChainDefinition? {
                return null
        }

        fun save(definition: ApprovalChainDefinition): ApprovalChainDefinition? {
                return null
        }

}
