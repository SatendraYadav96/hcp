package com.squer.hcp.persistence

interface BaseMapper<T> {
    fun insert(entity: T)

    fun update(entity: T)
}
