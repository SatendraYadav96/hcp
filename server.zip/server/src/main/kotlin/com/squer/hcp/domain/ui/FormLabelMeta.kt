package com.squer.hcp.domain.ui

import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SquerEntity
import javax.persistence.Column

@EntityMeta(prefix = "fmlbl", tableName = "form_label_meta")
class FormLabelMeta: java.io.Serializable, SquerEntity() {

    var code: String? = null

    var defaultValue: String? = null

    var customValue: String? = null

}
