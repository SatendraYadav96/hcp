package com.squer.hcp.domain

import com.squer.hcp.domain.enums.DoctorApprovalStatus
import com.squer.hcp.domain.enums.DoctorStatus
import com.squer.hcp.security.domain.AuditableEntity

class Doctor: java.io.Serializable, AuditableEntity() {

    var name: String? = null

    var ciName: String?  = null

    var code: String? = null

    var location: Location? = null

    var externalCode: String? = null

    var phone: String? = null

    var email: String? = null

    var status: DoctorStatus? = null

    var panNo: String? = null

    var gstNo: String? = null

    var approvalStatus: DoctorApprovalStatus? = null

    var fmvDetails: FMVDetails?  =null
}
