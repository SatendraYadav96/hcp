package com.squer.hcp.security.domain

import com.squer.hcp.persistence.EntityMeta
import javax.persistence.*

@EntityMeta(prefix = "srole", tableName = "security_role")
class SecurityRole: java.io.Serializable, AuditableEntity() {

    var name: String? =  null

    var ciName: String? =  null

    var privileges: Set<SecurityPrivilege>? = HashSet<SecurityPrivilege>()
}
