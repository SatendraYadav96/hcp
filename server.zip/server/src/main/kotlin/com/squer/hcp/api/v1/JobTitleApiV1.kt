package com.squer.hcp.api.v1

import com.squer.hcp.controller.JobTitleController
import com.squer.hcp.service.JobTitleService
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag

import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/v1/jobtitle")
@Tag(name = "V1 Jobtitle APIs")
@SecurityRequirement(name = "bearer-key")
@CrossOrigin
class JobTitleApiV1(
    jobTitleService: JobTitleService
) :
    JobTitleController(
        jobTitleService = jobTitleService
    )
