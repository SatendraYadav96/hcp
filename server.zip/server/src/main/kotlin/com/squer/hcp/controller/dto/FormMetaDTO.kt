package com.squer.hcp.controller.dto

import com.squer.hcp.domain.ui.FormLabelMeta

class FormMetaDTO {
    var id: Long? = null
    var code: String? = null
    var title: String? = null
    var fields: Map<String, FormLabelMeta> = mutableMapOf<String, FormLabelMeta>()
}
