package com.squer.hcp.security.domain.enum

enum class UserStatusEnum {
    ACTIVE, IN_ACTIVE
}