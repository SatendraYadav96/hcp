package com.squer.hcp.security.dto

data class LoginSuccessResponse(
    val success: Boolean? = false,
    val token: String?
)
