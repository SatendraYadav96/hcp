package com.squer.hcp.service

import com.squer.hcp.domain.*
import com.squer.hcp.domain.enums.ApprovalChainType

interface ApprovalService {
    fun resolveApprovalChain(employeeId: String, owner: Doctor, ownerType: ApprovalChainType): List<ApprovalChainInstanceDetails>
}
