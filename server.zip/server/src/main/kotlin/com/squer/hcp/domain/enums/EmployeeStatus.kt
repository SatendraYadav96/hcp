package com.squer.hcp.domain.enums

enum class EmployeeStatus {
    ACTIVE, INACTIVE
}
