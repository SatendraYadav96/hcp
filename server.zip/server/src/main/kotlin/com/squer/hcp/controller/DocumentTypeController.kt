package com.squer.hcp.controller

import com.squer.hcp.domain.DocumentType
import com.squer.hcp.domain.enums.DocumentTypeOwner
import com.squer.hcp.domain.enums.DocumentTypeStatus
import com.squer.hcp.service.DocumentTypeService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*


@Slf4j
open class DocumentTypeController @Autowired constructor(
    private val documentTypeService: DocumentTypeService
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @GetMapping("/search/{ownerType}")
    open fun searchDocumentTypes(@PathVariable ownerType: DocumentTypeOwner, @RequestParam status: DocumentTypeStatus?): ResponseEntity<*> {
        return ResponseEntity<Any?>(documentTypeService.findTypesForOwnerType(ownerType, status), HttpStatus.OK)
    }

    @PostMapping("/")
    open fun create(@RequestBody type: DocumentType): ResponseEntity<*> {
        return ResponseEntity<Any?>(documentTypeService.createType(type), HttpStatus.OK)
    }

    @PutMapping("/{id}")
    open fun create(@PathVariable id: Long, @RequestBody type: DocumentType): ResponseEntity<*> {
        return ResponseEntity<Any?>(documentTypeService.createType(type), HttpStatus.OK)
    }

}
