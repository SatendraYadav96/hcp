package com.squer.hcp.repository

import com.squer.hcp.domain.ApprovalChainDefinition
import com.squer.hcp.domain.ApprovalChainDetails
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
class ApprovalChainDetailRepository { //: JpaRepository<ApprovalChainDetails, Long> {
    fun save(chainDetails: ApprovalChainDetails): ApprovalChainDetails {
        return chainDetails
    }
}
