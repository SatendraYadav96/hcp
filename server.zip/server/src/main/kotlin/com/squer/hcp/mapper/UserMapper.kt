package com.squer.hcp.mapper

import com.squer.hcp.persistence.BaseMapper
import com.squer.hcp.security.domain.User
import org.apache.ibatis.annotations.*

@Mapper
interface UserMapper: BaseMapper<User> {
    @Select("SELECT * from USERS where id=#{id}")
    @ResultMap("usersResultMap")
    fun findUserById(id: String): User?

    @Select("SELECT * from USERS where username = #{username}")
    @ResultMap("usersResultMap")
    fun findByUsername(username: String): User?

    @Insert("<script>INSERT INTO USERS(username, password, status, created_at, created_by, updated_at, updated_by) " +
            " values ()(</script>")
    override fun insert(user: User)

    @Update("UPDATE USERS set username=#{username}, password=#{password}, " +
            " status=#{status}, updated_at=#{updatedAt}, updated_by=#{updatedBy} where id=#{id}")
    override fun update(user: User)

}
