package com.squer.hcp.domain

import com.squer.hcp.security.domain.AuditableEntity

class HCPBankDetails: java.io.Serializable, AuditableEntity() {
    var doctor: Doctor? = null

    var address: String? = null

    var benificiaryName: String? = null

    var nameOfBank: String? = null

    var bankBranch: String? = null

    var bankAccountNumber: String? = null

    var ifscCode: String? = null

    var comments: String? = null

    //TODO
    /*@PostLoad
    fun onRestore() {
        bankAccountNumber = AESUtil.decrypt(bankAccountNumber)
    }*/

}
