package com.squer.hcp.security.domain

import com.squer.hcp.persistence.EntityMeta
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@EntityMeta(prefix="spriv", tableName = "security_privilege")
class SecurityPrivilege: java.io.Serializable, SquerEntity() {

    var name: String? = null

    var ciName: String? = null
}
