package com.squer.hcp.domain.enums

enum class LOVStatusEnum {
    ACTIVE, INACTIVE
}
