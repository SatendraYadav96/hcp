package com.squer.hcp.service.impl

import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import com.squer.hcp.domain.HCPDocumentStore
import com.squer.hcp.domain.enums.ApprovalChainType
import com.squer.hcp.repository.DoctorRepository
import com.squer.hcp.repository.filters.DoctorFilter
import com.squer.hcp.service.ApprovalService
import com.squer.hcp.service.DoctorService
import com.squer.hcp.service.DocumentStoreService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.jpa.domain.Specification
import org.springframework.stereotype.Service


@Service
@Slf4j
class DoctorServiceImpl @Autowired constructor(
    private val doctorRepository: DoctorRepository,
    private val documentService: DocumentStoreService,
    private val approvalService: ApprovalService
) : DoctorService {

    private val log = LoggerFactory.getLogger(javaClass)

    @Value("\${app.search.page.size}")
    private var pageSize: Int = 0

    override fun searchDoctors(filter: Doctor, page: Int): Page<Doctor> {
        val spec: Specification<Doctor> = DoctorFilter(filter)
        return doctorRepository.findAll(spec, PageRequest.of(page, pageSize))
    }

    override fun findDoctor(id: String): Doctor? {
        //TODO, check locations
        return doctorRepository.findById(id)
    }

    override fun registerDoctor(employeeId: String, doctor: Doctor, documents: MutableList<HCPDocumentStore>): Doctor {

        val doctor = doctorRepository.save(doctor)
        documents.forEach {
            it.owner = doctor
            documentService.storeDocument(it)
        }
        approvalService.resolveApprovalChain(employeeId, doctor, ApprovalChainType.HCP )
        return doctor
    }
}
