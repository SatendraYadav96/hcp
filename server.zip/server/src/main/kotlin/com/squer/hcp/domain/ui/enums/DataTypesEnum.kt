package com.squer.hcp.domain.ui.enums

enum class DataTypesEnum {
    STRING, DATE, INTEGER, DOUBLE
}
