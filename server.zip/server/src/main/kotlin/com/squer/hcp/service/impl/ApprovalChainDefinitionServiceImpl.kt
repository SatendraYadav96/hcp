package com.squer.hcp.service.impl

import com.squer.hcp.domain.ApprovalChainDefinition
import com.squer.hcp.repository.ApprovalChainDefinitionRepository
import com.squer.hcp.repository.ApprovalChainDetailRepository
import com.squer.hcp.repository.EmployeeRepository
import com.squer.hcp.service.ApprovalChainDefinitionService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
@Slf4j
class ApprovalChainDefinitionServiceImpl @Autowired constructor(
    private val approvalChainDefinitionRepository: ApprovalChainDefinitionRepository,
    private val approvalChainDetailRepository: ApprovalChainDetailRepository,
    private val employeeRepository: EmployeeRepository
) : ApprovalChainDefinitionService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun create(chainDefinition: ApprovalChainDefinition): ApprovalChainDefinition? {
        for(it in chainDefinition.details) {
            it.definition = chainDefinition
        }
        val definition = approvalChainDefinitionRepository.save(chainDefinition)
        /*chainDefinition.details.forEach {
            it.definition = definition
        }
        approvalChainDetailRepository.saveAll(chainDefinition.details) */
        return definition
    }
}
