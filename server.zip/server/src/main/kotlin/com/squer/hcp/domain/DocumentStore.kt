package com.squer.hcp.domain

import com.squer.hcp.security.domain.SquerEntity
import javax.persistence.*

open class DocumentStore: java.io.Serializable, SquerEntity() {

    var documentPath: String? = null

    var file_name: String?  = null

    var documentType: DocumentType? = null

    var content: ByteArray? = null
}

class HCPDocumentStore: DocumentStore() {

    var owner: Doctor? = null
}


