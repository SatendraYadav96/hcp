package com.squer.hcp.service.impl

import com.squer.hcp.domain.Employee
import com.squer.hcp.repository.EmployeeRepository
import com.squer.hcp.service.EmployeeService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
@Slf4j
class EmployeeServiceImpl @Autowired constructor(
    private val employeeRepository: EmployeeRepository
) : EmployeeService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun findByUserId(userId: String): Employee? {
        return employeeRepository.findEmployeeByUserId(userId)
    }


}
