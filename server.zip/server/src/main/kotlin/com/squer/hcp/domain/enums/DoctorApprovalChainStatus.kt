package com.squer.hcp.domain.enums

enum class DoctorApprovalChainStatus{
    PENDING, APPROVED, REJECTED, PASSED
}
