package com.squer.hcp.security.domain

open class SquerEntity {
    lateinit var id: String
}
