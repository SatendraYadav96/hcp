package com.squer.hcp.domain.enums

enum class ApprovalChainType {
    HCP, EVENT
}
