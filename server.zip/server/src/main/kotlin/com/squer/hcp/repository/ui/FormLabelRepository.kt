package com.squer.hcp.repository.ui

import com.squer.hcp.domain.ui.FormLabelMeta
import com.squer.hcp.domain.ui.FormMeta
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
class FormLabelRepository { //: JpaRepository<FormLabelMeta, Long> {

    fun getFormLabelMetaByCode(code: String): FormLabelMeta? {
        return null
    }
}
