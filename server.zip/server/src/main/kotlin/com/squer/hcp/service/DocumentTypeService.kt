package com.squer.hcp.service

import com.squer.hcp.domain.DocumentType
import com.squer.hcp.domain.enums.DocumentTypeOwner
import com.squer.hcp.domain.enums.DocumentTypeStatus

interface DocumentTypeService {
    fun findTypesForOwnerType(ownerType: DocumentTypeOwner, status: DocumentTypeStatus?): List<DocumentType>?

    fun createType(documentType: DocumentType): DocumentType?

    fun changeStatus(id: String, newStatus: DocumentTypeStatus): DocumentType?
}
