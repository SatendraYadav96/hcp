package com.squer.hcp.repository.filters

import com.squer.hcp.domain.Doctor
import org.springframework.data.jpa.domain.Specification
import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root


class DoctorFilter constructor(val filter: Doctor): Specification<Doctor> {

    override fun toPredicate(
        root: Root<Doctor>,
        query: CriteriaQuery<*>,
        criteriaBuilder: CriteriaBuilder
    ): Predicate? {
        var p: Predicate = criteriaBuilder.disjunction()
        val locationPredicate = criteriaBuilder.equal(root.get<Long>("location"), filter.location!!.id)
        if (filter.name != null) {
            val namePredicate = criteriaBuilder.like(root.get<String>("ciName"), "${filter.name?.lowercase()?.trim()}%")
            p = criteriaBuilder.and(locationPredicate, namePredicate)
        }
        return p
    }
}
