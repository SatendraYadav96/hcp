package com.squer.hcp.repository

import com.squer.hcp.domain.Doctor
import com.squer.hcp.repository.filters.DoctorFilter
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.jpa.domain.Specification
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.stereotype.Repository

@Repository
class DoctorRepository { /*: JpaRepository<Doctor, Long>, JpaSpecificationExecutor<Doctor>,
    PagingAndSortingRepository<Doctor, Long> { */
    fun findAll(filter: Specification<Doctor>, pageRequest: PageRequest): Page<Doctor> {
        return Page.empty()
    }

    fun findById(id: String): Doctor? {
        return null
    }

    fun save(doctor: Doctor): Doctor {
        return doctor
    }
}
