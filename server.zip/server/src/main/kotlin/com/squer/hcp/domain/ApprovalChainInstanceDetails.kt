package com.squer.hcp.domain

import com.squer.hcp.domain.enums.DoctorApprovalChainStatus
import com.squer.hcp.security.domain.SquerEntity
import java.util.Date

open class ApprovalChainInstanceDetails: java.io.Serializable, SquerEntity() {

    var definition: ApprovalChainDefinition? = null

    var person: Employee? = null

    var inQueueFrom: Date? = null

    var approvalStatus: DoctorApprovalChainStatus? = null

    var actionDate: Date? =  null

    var detailsGroupId: String? = null

    var currentApprover: Boolean = false

    var levelNo: Int = 0

}

class HCPApprovalChainInstance: ApprovalChainInstanceDetails() {

    var owner: Doctor? = null
}



