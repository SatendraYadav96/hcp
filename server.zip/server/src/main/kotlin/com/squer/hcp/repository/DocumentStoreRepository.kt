package com.squer.hcp.repository

import com.squer.hcp.domain.DocumentStore
import org.springframework.stereotype.Repository

@Repository
class DocumentStoreRepository {//: JpaRepository<DocumentStore, Long> {
    fun save(documentStore: DocumentStore): DocumentStore? {
        return null
    }
}
