package com.squer.hcp.service.ui.impl

import com.squer.hcp.domain.ui.FormLabelMeta
import com.squer.hcp.repository.ui.FormLabelRepository
import com.squer.hcp.service.ui.FormLabelService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.cache.annotation.Cacheable
import org.springframework.stereotype.Service

@Service
open class FormLabelServiceImpl @Autowired constructor(
    private val formLabelRepository: FormLabelRepository
): FormLabelService {


    @Cacheable(cacheNames = ["labelStore"], key = "#code")
    override fun fetchLabel(code: String): FormLabelMeta? {
        return formLabelRepository.getFormLabelMetaByCode(code)
    }
}
