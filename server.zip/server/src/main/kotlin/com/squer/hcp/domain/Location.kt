package com.squer.hcp.domain

import com.squer.hcp.domain.enums.LocationStatus
import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.AuditableEntity

@EntityMeta("locat", tableName = "location")
class Location: java.io.Serializable, AuditableEntity() {
    var name: String? = null

    var ciName: String? = null

    var locationType: LocationType? = null

    var parent: Location? = null

    var status: LocationStatus? = null

}
