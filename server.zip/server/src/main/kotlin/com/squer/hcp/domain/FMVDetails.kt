package com.squer.hcp.domain

import com.squer.hcp.security.domain.AuditableEntity

class FMVDetails: java.io.Serializable, AuditableEntity() {
    var doctor: Doctor? = null

    var tier: ListOfValues? = null

    var place: String? = null

    var qualification: String? = null

    var speciality: ListOfValues? = null

    var experienceInYears: Int? = null

    var hourlyRate: Double? = null

    var comments: String? = null

}
