package com.squer.hcp.controller.dto

data class InvalidArgumentResponse (
    val argument: String,
    val message: String
)
