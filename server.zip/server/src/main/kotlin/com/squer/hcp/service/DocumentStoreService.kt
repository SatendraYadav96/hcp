package com.squer.hcp.service

import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.DocumentStore
import org.springframework.data.domain.Page

interface DocumentStoreService {
    fun storeDocument(documentStore: DocumentStore): DocumentStore?
}
