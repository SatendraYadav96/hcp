package com.squer.hcp.domain.enums

enum class DoctorStatus {
    ACTIVE, INACTIVE
}
