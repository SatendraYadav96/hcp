package com.squer.hcp.domain

import com.squer.hcp.domain.enums.EmployeeStatus
import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.AuditableEntity
import com.squer.hcp.security.domain.User

@EntityMeta(prefix = "emply", tableName = "employee")
class Employee: java.io.Serializable, AuditableEntity() {

    var name: String? = null

    var ciName: String? = null

    var jobTitle: JobTitle? = null

    var location: Location? = null

    var code: String? = null

    var manager: Employee? = null

    var status: EmployeeStatus? = null

    var user: User? = null
}
