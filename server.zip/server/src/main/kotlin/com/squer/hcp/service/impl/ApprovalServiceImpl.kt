package com.squer.hcp.service.impl

import com.squer.hcp.domain.ApprovalChainInstanceDetails
import com.squer.hcp.domain.Doctor
import com.squer.hcp.domain.HCPApprovalChainInstance
import com.squer.hcp.domain.enums.ApprovalChainType
import com.squer.hcp.domain.enums.DoctorApprovalChainStatus
import com.squer.hcp.repository.ApprovalChainDefinitionRepository
import com.squer.hcp.repository.ApprovalChainInstanceRepository
import com.squer.hcp.repository.EmployeeRepository
import com.squer.hcp.service.ApprovalService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*


@Service
@Slf4j
class ApprovalServiceImpl @Autowired constructor(
    private val approvalChainDefinitionRepository: ApprovalChainDefinitionRepository,
    private val approvalChainInstanceRepository: ApprovalChainInstanceRepository,
    private val employeeRepository: EmployeeRepository
) : ApprovalService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun resolveApprovalChain(employeeId: String, owner: Doctor, ownerType: ApprovalChainType): List<ApprovalChainInstanceDetails> {
        val managers = employeeRepository.findAllManagers(employeeId)?.map{it.jobTitle?.id to it}!!.toMap()
        val chainDefinition = approvalChainDefinitionRepository.findByType(ownerType)
        if (chainDefinition == null)
            return mutableListOf<ApprovalChainInstanceDetails>()
        val groupId = UUID.randomUUID().toString()
        var i =0
        var instances = mutableListOf<HCPApprovalChainInstance>()
        var listOfApprovers = mutableListOf<String>()
        chainDefinition.details.sortedBy { it.levelNo }.forEach {
            if (managers[it.jobRole?.id] != null) {
                val approver = managers[it.jobRole?.id]
                if (!listOfApprovers.contains(approver!!.id)) {
                    var chainInstance = HCPApprovalChainInstance()
                    chainInstance.detailsGroupId = groupId
                    chainInstance.levelNo = it.levelNo
                    chainInstance.approvalStatus = DoctorApprovalChainStatus.PENDING
                    chainInstance.currentApprover = if (i == 0) true else false
                    chainInstance.definition = chainDefinition
                    chainInstance.inQueueFrom = Date()
                    chainInstance.person = managers[it.jobRole?.id]
                    chainInstance.owner = owner
                    instances.add(chainInstance)
                    listOfApprovers.add(approver?.id!!)
                    i++
                }
            }
            if (it.jobRole?.commonFunction == true) {
                val employees = employeeRepository.findAllByJobTitle(it.jobRole!!)
                employees?.forEach {employee ->
                    if (!listOfApprovers.contains(employee.id)) {
                        var chainInstance = HCPApprovalChainInstance()
                        chainInstance.detailsGroupId = groupId
                        chainInstance.levelNo = it.levelNo
                        chainInstance.approvalStatus = DoctorApprovalChainStatus.PENDING
                        chainInstance.currentApprover = if (i == 0) true else false
                        chainInstance.definition = chainDefinition
                        chainInstance.inQueueFrom = Date()
                        chainInstance.person = employee
                        chainInstance.owner = owner
                        instances.add(chainInstance)
                        listOfApprovers.add(employee.id!!)
                        i++
                    }
                }
            }
        }
        approvalChainInstanceRepository.saveAll(instances)
        return mutableListOf<ApprovalChainInstanceDetails>()
    }
}
