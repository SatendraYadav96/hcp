package com.squer.hcp.controller.dto

import com.squer.hcp.domain.ui.MenuAction

class MenuPojo {
    constructor(menuAction: MenuAction) {
        id = menuAction.id!!
        name = menuAction.name!!
        path = menuAction.path
        parentId = menuAction.parent?.id
    }
    var id: String? = null
    lateinit var name: String
    var path: String? = null
    var parentId: String? = null
    var childMenus: List<MenuPojo> = mutableListOf<MenuPojo>()
}
