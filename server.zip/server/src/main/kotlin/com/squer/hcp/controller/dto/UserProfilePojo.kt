package com.squer.hcp.controller.dto

import com.squer.hcp.domain.Employee

class UserProfilePojo {
    var id: String = ""
    lateinit var userName: String
    lateinit var fullName: String
    lateinit var employee: Employee
}
