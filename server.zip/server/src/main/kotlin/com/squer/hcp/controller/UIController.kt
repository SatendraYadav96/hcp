package com.squer.hcp.controller

import com.squer.hcp.controller.dto.MenuPojo
import com.squer.hcp.domain.ui.MenuAction
import com.squer.hcp.security.config.SecurityConstants
import com.squer.hcp.security.dto.LoginRequest
import com.squer.hcp.security.dto.LoginSuccessResponse
import com.squer.hcp.security.jwt.JwtTokenProvider
import com.squer.hcp.security.util.SecurityUtility
import com.squer.hcp.service.MenuActionService
import com.squer.hcp.service.UserService
import com.squer.hcp.service.ui.FormService
import com.squer.hcp.validator.MapValidationErrorService
import com.squer.hcp.validator.UserValidator
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.validation.BindingResult
import org.springframework.web.bind.annotation.*
import javax.validation.Valid



@Slf4j
open class UIController @Autowired constructor(
    private val menuActionService: MenuActionService,
    private val formService: FormService
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @GetMapping("/menus/{userId}")
    open fun getMenusForUser(@PathVariable("userId") userId: Long): ResponseEntity<*> {
        val parentMenus = menuActionService.findParentMenus(null)
        val allChildMenus = menuActionService.findMenuActionByUser(userId)?.map{
            MenuPojo(it)
        }?.groupBy({it.parentId})
        val menus = mutableListOf<MenuPojo>()
        parentMenus?.forEach {
            val parent  = MenuPojo(it)
            parent.childMenus = allChildMenus?.get(parent.id) ?: mutableListOf<MenuPojo>()
            menus.add(parent)
        }
        return ResponseEntity(menus, HttpStatus.OK)
    }

    @GetMapping("/form/{formCode}")
    open fun getFormMeta(@PathVariable("formCode")formCode: String): ResponseEntity<*> {
        return ResponseEntity(formService.getFormMeta(formCode), HttpStatus.OK)
    }
}
