package com.squer.hcp.controller

import com.squer.hcp.controller.dto.HCPDetails
import com.squer.hcp.controller.dto.InvalidArgumentResponse
import com.squer.hcp.domain.*
import com.squer.hcp.service.ApprovalChainDefinitionService
import com.squer.hcp.service.DoctorService
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile


@Slf4j
open class ApprovalChainDefinitionController @Autowired constructor(
    private val approvalChainDefinitionService: ApprovalChainDefinitionService
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @PostMapping("/")
    open fun createChainDefinition(@RequestBody approvalChainDefinition: ApprovalChainDefinition): ResponseEntity<*> {
        return ResponseEntity<Any?>(approvalChainDefinitionService.create(approvalChainDefinition), HttpStatus.OK)
    }

}
