package com.squer.hcp.domain.enums

enum class DocumentTypeStatus {
    ACTIVE, INACTIVE
}
