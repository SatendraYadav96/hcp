package com.squer.hcp.service


import com.squer.hcp.domain.ui.MenuAction
import com.squer.hcp.security.domain.User


interface MenuActionService {
    fun findMenuActionByUser(userId: Long): List<MenuAction>?

    fun findParentMenus(parentId: Long?): List<MenuAction>?
}
