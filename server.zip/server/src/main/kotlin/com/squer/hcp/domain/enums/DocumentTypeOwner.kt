package com.squer.hcp.domain.enums

enum class DocumentTypeOwner {
    HCP, EVENT
}
