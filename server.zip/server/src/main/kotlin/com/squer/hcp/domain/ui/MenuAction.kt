package com.squer.hcp.domain.ui

import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SecurityPrivilege
import com.squer.hcp.security.domain.SquerEntity

@EntityMeta(prefix="menua", tableName = "menu_action")
class MenuAction: java.io.Serializable, SquerEntity() {

    var uiInterface: String? = null

    var name: String? = null

    var path: String? = null

    var privilege: SecurityPrivilege? = null

    var icon: String? = null

    var parent: MenuAction? = null
}
