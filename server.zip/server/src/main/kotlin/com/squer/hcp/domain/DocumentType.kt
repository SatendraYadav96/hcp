package com.squer.hcp.domain

import com.squer.hcp.domain.enums.DocumentTypeOwner
import com.squer.hcp.domain.enums.DocumentTypeStatus
import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.SquerEntity

@EntityMeta(prefix = "doctt", tableName = "document_type")
class DocumentType: java.io.Serializable, SquerEntity() {

    var name: String? = null

    var ciName: String? = null

    var ownerType: DocumentTypeOwner? = null

    var required: Boolean = false

    var maxNumDocuments: Int = 0

    var maxSize: Int = 0

    var types: String? = null

    var status: DocumentTypeStatus? = null

}
