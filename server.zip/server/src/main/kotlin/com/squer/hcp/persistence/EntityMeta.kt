package com.squer.hcp.persistence

@Retention(AnnotationRetention.RUNTIME)
annotation class EntityMeta(val prefix: String, val tableName: String)
