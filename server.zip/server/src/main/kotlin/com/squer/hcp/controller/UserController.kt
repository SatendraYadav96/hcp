package com.squer.hcp.controller

import com.squer.hcp.controller.dto.UserProfilePojo
import com.squer.hcp.domain.Employee
import com.squer.hcp.security.config.SecurityConstants
import com.squer.hcp.security.domain.User
import com.squer.hcp.security.dto.LoginRequest
import com.squer.hcp.security.dto.LoginSuccessResponse
import com.squer.hcp.security.jwt.JwtTokenProvider
import com.squer.hcp.security.util.SecurityUtility
import com.squer.hcp.service.EmployeeService
import com.squer.hcp.service.UserService
import com.squer.hcp.validator.MapValidationErrorService
import com.squer.hcp.validator.UserValidator
import lombok.extern.slf4j.Slf4j
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.validation.BindingResult
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@Slf4j
open class UserController @Autowired constructor(
    private val userService: UserService,
    private val userValidator: UserValidator,
    private val authenticationManager: AuthenticationManager,
    private val jwdTokenProvider: JwtTokenProvider,
    private val mapValidationErrorService: MapValidationErrorService,
    private val bCryptPasswordEncoder: BCryptPasswordEncoder,
    private val employeeService: EmployeeService
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @Autowired
    lateinit var securityUtility: SecurityUtility

    @PostMapping("/login")
    fun authenticateUser(
        @RequestBody loginRequest: @Valid LoginRequest,
        result: BindingResult
    ): ResponseEntity<*> {
        val errorMap = mapValidationErrorService.mapValidationService(result)
        if (errorMap != null) return errorMap
        val authentication: Authentication = authenticationManager.authenticate(
            UsernamePasswordAuthenticationToken(
                loginRequest.username,
                loginRequest.password
            )
        )
        SecurityContextHolder.getContext().authentication = authentication
        val jwt: String = SecurityConstants.TOKEN_PREFIX + jwdTokenProvider.generateToken(authentication)
        log.info("User '${loginRequest.username}' is logged in and authenticated")
        //return ResponseEntity.ok<Any>(LoginSuccessResponse(true, jwt))
        return ResponseEntity.ok<Any>(userService.restore("users00000000000000000000000000000003"))
    }


    @PutMapping(value = ["/setpassword"])
    open fun setPassword(@RequestBody loginRequest: LoginRequest): ResponseEntity<*>? {
        var user = userService.findByUsername(loginRequest.username)
        user!!.password = loginRequest.password
        userService.saveUser(user)
        return ResponseEntity<Any?>(user, HttpStatus.OK)
    }


    @GetMapping(value=["/profile"])
    open fun getLoggedInUserProfile(): ResponseEntity<*>? {
        val principal =  SecurityContextHolder.getContext().authentication.principal as User
        val employee: Employee? = employeeService.findByUserId(principal.id!!)
        val profile = UserProfilePojo()
        profile.id = principal.id!!
        profile.fullName = principal.fullName!!
        profile.userName = principal.username!!
        profile.employee = employee!!
        return ResponseEntity<Any?>(profile, HttpStatus.OK)
    }

    private fun returnInvalidResponseEntity(): ResponseEntity<Map<String, String>> {
        val errorMap: MutableMap<String, String> = HashMap()
        errorMap["message"] = "Invalid user details"
        errorMap["error"] = "true"
        return ResponseEntity(errorMap, HttpStatus.BAD_REQUEST)
    }

}
