package com.squer.hcp.domain.enums

enum class DoctorApprovalStatus{
    NOT_INITIATED, PENDING, APPROVED, REJECTED
}
