package com.squer.hcp.domain

import com.squer.hcp.domain.enums.ApprovalChainType
import com.squer.hcp.persistence.EntityMeta
import com.squer.hcp.security.domain.AuditableEntity
import lombok.EqualsAndHashCode
import javax.persistence.*

@EntityMeta(prefix = "acdfn", tableName = "approval_chain_definition")
class ApprovalChainDefinition: java.io.Serializable, AuditableEntity() {

    var name: String? = null

    var ciName: String? = null

    var type: ApprovalChainType?  = null

    var details: Set<ApprovalChainDetails> = HashSet<ApprovalChainDetails>()

}

